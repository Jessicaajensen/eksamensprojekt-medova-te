
const update = function (newActive) {
  const newActivePos = newActive.dataset.pos;

  const current = elems.find((elem) => elem.dataset.pos === "0");
  const prev = elems.find((elem) => elem.dataset.pos === "-1");
  const next = elems.find((elem) => elem.dataset.pos === "1");

  if (current) current.classList.remove("carousel__item_active");

  [current, prev, next].forEach((item) => {
    const itemPos = item.dataset.pos;

    item.dataset.pos = getPos(itemPos, newActivePos);
  });
};

const getPos = function (current, active) {
  const diff = current - active;

  if (Math.abs(current - active) >= 2) {
    return -current;
  }

  return diff;
};

const burger = document.getElementById("burger-menu-wrapper");

if (burger) {
  console.log("hej");
  burger.addEventListener("click", () => {
    document.getElementById("nav").classList.toggle("open");
  });
}